import java.util.ArrayList;
import java.util.Locale;

public class DoingIt {

    String[] cars = { "BMW", "AUDI", "MERCEDES BENZ", "TOYOTA", "PORSCHE" };

    public void lab1() {
        System.out.println(cars[cars.length-2]);
        String str1 = cars.toString();
        System.out.println(str1.length());

        Boolean result = cars[0] == cars[1];
        System.out.println(result);
    }

    public void lab2() {
        Person[] students = new Person[3];
        int totalMark;
        students[0] = new Person();
        students[0].name = "Ellen";

        //System.out.println(totalMark); Compile error: Variable might not have been initialised
        //System.out.println(students[3]); Run-time error: NullPointerException (caused by an element of ‘students’ not ‘students’ itself)
        //System.out.println(students[]);
        System.out.println();


    }

    public void lab3() {
        ArrayListlist <Double> list = new ArrayList<Double>();

        list.add(1.38);
        list.add(2.56);
        list.add(4.3);
        list.add(4.3);
        list.add(4.3);

        System.out.println(list);

    }

    public void lab4() {
        String str1 = "HeLLo";
        String result1 = str1.substring(0,4).toUpperCase().substring(1,3)result1.toLowerCase();

    }

    public void lab5() {

    }

    public void lab6() {

    }
}
