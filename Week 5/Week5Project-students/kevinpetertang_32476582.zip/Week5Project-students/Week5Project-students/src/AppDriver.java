public class AppDriver {
    public static void main(String[] args) {
        DoingIt mC = new DoingIt();
        // Enable one method at a time
         mC.lab1();
        mC.lab2();
         mC.lab3();
//         mC.lab4();
//         mC.lab5();



    }
}
